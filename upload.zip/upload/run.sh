cd $(dirname $0)
make >> /dev/null
chmod +x ./bin/main
./bin/main
